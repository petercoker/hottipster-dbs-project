﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HotTipster
{
    public enum HorseNameEnum
    {
        Cheetah,
        Thunder,
        Flash,
        Bloat,
        Quicksilver,
        Lightning,
        QuickFeet,
        Speedee,
        Zeus,
        President,
        Sheriff,
        Deputy,
        Lucky,
        Pablo,
        Horseshoe,
        Barley,
        Bronco,
        Blazer,
        Wilbur,
        Buck,
        Franklin,
        Kentucky,
        Trigger,
        Blacksmith,
        Buckeye,
        Queen,
        Washington,
        Connecticut,
        Obama,
        King,
        Jockey,
        Clydesdale,
        Wrangler,
        Jupiter,
        Tennessee,
        Texas,
        Diesel,
        Tank,
        Colorado,
        Ridgeline,
        Quarterback,
        Shoelace,
        Colonel,
        Lincoln,
        Steeltoe,
        Officer,
        Rushmore
    }
}
