﻿
namespace HotTipster
{
    public enum RaceCourseEnum
    {
        Sandown,
        Ayr,
        Fairyhouse,
        Doncaster,
        Towcester,
        Goodwood,
        Kelso,
        Punchestown,
        Ascot,
        Bangor,
        Dundalk,
        Haydock,
        Perth,
        York,
        Chester,
        Kilbeggan,
        Cork
    }
}
